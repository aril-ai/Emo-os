# ============================================================================
# emo-core-kiosk.bb
#
# Packages the QML application, systemd user service, and the
# asteroid-launcher drop-in override that silences the default UI.
#
# Add to local.conf (or your image recipe):
#   IMAGE_INSTALL:append = " emo-core-kiosk emo-kiosk-runner"
# ============================================================================

SUMMARY     = "EMO Robot Kiosk — QML assets and kiosk systemd service"
DESCRIPTION = "Transforms an AsteroidOS smartwatch into a dedicated standalone \
EMO robot virtual companion. Disables asteroid-launcher and starts a fullscreen \
QML-based EMO robot personality under the 'ceres' user systemd session. \
Handles idle, sleep, charging, hunger, shake/dizzy, and touch interaction states."
HOMEPAGE    = "https://github.com/your-org/meta-emo"
SECTION     = "x11/applications"
LICENSE     = "MIT"
LIC_FILES_CHKSUM = \
    "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = " \
    file://main.qml                                     \
    file://EyeUnit.qml                                  \
    file://ZzzParticle.qml                              \
    file://emo-core-kiosk.service                       \
    file://asteroid-launcher.service.d/override.conf    \
"

S = "${WORKDIR}/src"

# We manage the symlink manually in do_install; suppress the systemd
# bbclass auto-enable mechanism which does not handle user-scope units
# correctly across all OE releases.
inherit systemd
SYSTEMD_SERVICE:${PN}     = ""
SYSTEMD_AUTO_ENABLE:${PN} = "disable"

# Runtime dependencies — all must be present in the target rootfs
RDEPENDS:${PN} = " \
    emo-kiosk-runner        \
    qtdeclarative           \
    qtdeclarative-qmlplugins \
    qtsensors               \
    qtsensors-qmlplugins    \
    nemo-qml-plugin-mce     \
    fontconfig              \
    ttf-dejavu-sans         \
"

# ── Installation ─────────────────────────────────────────────────────────────
do_install() {
    # QML assets
    install -d "${D}${datadir}/emo-kiosk"
    install -m 0644 "${WORKDIR}/main.qml"        "${D}${datadir}/emo-kiosk/"
    install -m 0644 "${WORKDIR}/EyeUnit.qml"     "${D}${datadir}/emo-kiosk/"
    install -m 0644 "${WORKDIR}/ZzzParticle.qml" "${D}${datadir}/emo-kiosk/"

    # systemd user service + auto-enable symlink
    install -d "${D}${sysconfdir}/systemd/user"
    install -d "${D}${sysconfdir}/systemd/user/default.target.wants"
    install -m 0644 "${WORKDIR}/emo-core-kiosk.service" \
                    "${D}${sysconfdir}/systemd/user/emo-core-kiosk.service"
    ln -sf "/etc/systemd/user/emo-core-kiosk.service" \
           "${D}${sysconfdir}/systemd/user/default.target.wants/emo-core-kiosk.service"

    # Drop-in that silences asteroid-launcher when kiosk mode is active
    install -d "${D}${sysconfdir}/systemd/user/asteroid-launcher.service.d"
    install -m 0644 \
        "${WORKDIR}/asteroid-launcher.service.d/override.conf" \
        "${D}${sysconfdir}/systemd/user/asteroid-launcher.service.d/override.conf"

    # Sentinel file: ConditionPathExists=!/etc/emo-kiosk.enabled in the
    # override.conf evaluates to FALSE (service blocked) when this exists.
    install -d "${D}${sysconfdir}"
    touch "${D}${sysconfdir}/emo-kiosk.enabled"
}

FILES:${PN} = " \
    ${datadir}/emo-kiosk/                                                        \
    ${sysconfdir}/systemd/user/emo-core-kiosk.service                           \
    ${sysconfdir}/systemd/user/default.target.wants/emo-core-kiosk.service      \
    ${sysconfdir}/systemd/user/asteroid-launcher.service.d/override.conf        \
    ${sysconfdir}/emo-kiosk.enabled                                              \
"
