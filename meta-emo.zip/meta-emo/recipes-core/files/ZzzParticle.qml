// ============================================================================
//  ZzzParticle.qml  —  Single floating sleep particle
//
//  Instantiated ×4 via Repeater in main.qml.
//  Each index gets a unique staggered delay, size, and lateral drift so
//  they feel organic rather than synchronised.
// ============================================================================

import QtQuick 2.12

Item {
    id: particle

    // ── API ───────────────────────────────────────────────────────────────────
    property int  particleIndex: 0
    property bool active:        false
    property real baseX:         0
    property real baseY:         0

    // ── Per-index visual variation ────────────────────────────────────────────
    readonly property var fontSizes:  [26, 21, 17, 13]
    readonly property var startDelays:[0,  940, 1860, 2720]
    readonly property var labels:     ["Z", "Z", "z", "z"]
    readonly property var drifts:     [28, 36, 22, 42]   // lateral px drift

    // Resolved values for this instance
    readonly property int  mySize:  fontSizes [Math.min(particleIndex, 3)]
    readonly property int  myDelay: startDelays[Math.min(particleIndex, 3)]
    readonly property string myLabel: labels[Math.min(particleIndex, 3)]
    readonly property int  myDrift: drifts[Math.min(particleIndex, 3)]

    width:   mySize + 8
    height:  mySize + 8
    x:       baseX + particleIndex * 15
    y:       baseY
    opacity: 0

    Text {
        anchors.centerIn: parent
        text:        particle.myLabel
        font.pixelSize: particle.mySize
        font.bold:   particle.particleIndex < 2
        font.family: "Monospace"
        color:       "#4a8a9a"
        style:       Text.Outline
        styleColor:  "#1a3a4a"
    }

    SequentialAnimation {
        id:      floatAnim
        running: particle.active
        loops:   Animation.Infinite

        // Stagger start so particles feel independent
        PauseAnimation { duration: particle.myDelay }

        ParallelAnimation {
            // Float upward
            NumberAnimation {
                target: particle; property: "y"
                from:   particle.baseY
                to:     particle.baseY - 96 - particle.particleIndex * 14
                duration:    3600
                easing.type: Easing.OutCubic
            }
            // Drift sideways (direction alternates by index)
            NumberAnimation {
                target: particle; property: "x"
                from:   particle.baseX + particle.particleIndex * 15
                to:     particle.baseX + particle.particleIndex * 15
                        + (particle.particleIndex % 2 === 0 ? 1 : -1)
                        * particle.myDrift
                duration: 3600
                easing.type: Easing.InOutSine
            }
            // Slight tumble rotation
            NumberAnimation {
                target: particle; property: "rotation"
                from:   -12
                to:      15
                duration: 3600
            }
            // Opacity: fade in → hold → fade out
            SequentialAnimation {
                NumberAnimation {
                    target: particle; property: "opacity"
                    from: 0.0; to: 0.88; duration: 520
                }
                PauseAnimation { duration: 2260 }
                NumberAnimation {
                    target: particle; property: "opacity"
                    from: 0.88; to: 0.0; duration: 820
                }
            }
        }
    }

    // Snap back to origin when deactivated (sleep mode exits)
    onActiveChanged: {
        if (!active) {
            floatAnim.stop()
            particle.opacity  = 0
            particle.y        = baseY
            particle.x        = baseX + particleIndex * 15
            particle.rotation = 0
        }
    }
}