// ============================================================================
//  EyeUnit.qml  —  Single EMO Eye Component
//
//  Architecture: layered Canvas items, one per expression.  Only the active
//  layer has opacity 1.0; all others fade to 0.  The outer shell Rectangle
//  uses a vertical Scale transform driven by eyeOpenness for the blink squish.
//
//  Canvas colour rule: primaryColorStr is a plain CSS hex string (e.g.
//  "#00e5ff") — never use QML Color.toString() inside Canvas code paths
//  because it can return the non-standard "#aarrggbb" format.
//
//  Expressions: idle | happy | love | dizzy | hungry | charging | sleeping
// ============================================================================

import QtQuick 2.12

Item {
    id: eyeUnit

    // ── API ───────────────────────────────────────────────────────────────────
    property int    eyeW:              90
    property int    eyeH:              78
    property int    eyeRad:            18
    property string currentExpression: "idle"
    property string primaryColorStr:   "#00e5ff"   // CSS hex — used by Canvas
    property bool   isLeftEye:         true

    // Driven by main.qml's blinkSeq  (0.0 = closed, 1.0 = fully open)
    property real   eyeOpenness:       1.0

    width:  eyeW
    height: eyeH

    // ── Shell (outer rounded rectangle, clips all children) ───────────────────
    Rectangle {
        id:      eyeShell
        anchors.fill: parent
        radius:  eyeUnit.eyeRad
        color:   "#040e18"
        border.color: Qt.rgba(0, 0.9, 1.0, 0.36)
        border.width: 2
        clip:    true

        // Blink squash — collapses the whole eye vertically on its centre axis
        transform: Scale {
            origin.x: eyeShell.width  / 2
            origin.y: eyeShell.height / 2
            yScale:   eyeUnit.eyeOpenness
        }

        // ── Shared pixel-art scanline overlay (static, painted once) ──────────
        Canvas {
            id:      scanlines
            anchors.fill: parent
            opacity: 0.065
            z:       20    // always topmost inside the shell
            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)
                ctx.fillStyle = "#000000"
                for (var i = 0; i < height; i += 3) ctx.fillRect(0, i, width, 1)
            }
        }

        // ======================================================================
        //  1. IDLE / CHARGING  — glowing cyan iris with pupil & specular
        // ======================================================================
        Canvas {
            id:      idleCanvas
            anchors.fill: parent

            readonly property bool visActive:
                (eyeUnit.currentExpression === "idle" ||
                 eyeUnit.currentExpression === "charging")

            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 220 } }

            onOpacityChanged: if (opacity > 0.5) requestPaint()
            onVisibleChanged: if (visible)       requestPaint()
            // Repaint when the colour token changes (e.g. green while charging)
            property string col: eyeUnit.primaryColorStr
            onColChanged: if (visActive) requestPaint()

            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                var cx  = width  / 2
                var cy  = height / 2
                var R   = Math.min(width, height) * 0.372
                var c   = eyeUnit.primaryColorStr

                // ── Soft outer glow (radial gradient) ──
                var glow = ctx.createRadialGradient(cx, cy, R * 0.5, cx, cy, R * 1.3)
                glow.addColorStop(0.0, hexToRgba(c, 0.50))
                glow.addColorStop(1.0, "rgba(0,0,0,0)")
                ctx.beginPath()
                ctx.arc(cx, cy, R * 1.3, 0, Math.PI * 2)
                ctx.fillStyle = glow
                ctx.fill()

                // ── Main iris (radial gradient for depth) ──
                var iris = ctx.createRadialGradient(
                    cx - R * 0.18, cy - R * 0.18, R * 0.06,
                    cx, cy, R)
                iris.addColorStop(0.0, lightenHex(c, 1.28))
                iris.addColorStop(1.0, darkenHex(c,  0.72))
                ctx.beginPath()
                ctx.arc(cx, cy, R, 0, Math.PI * 2)
                ctx.fillStyle = iris
                ctx.fill()

                // ── Dark slit pupil ──
                ctx.beginPath()
                ctx.arc(cx, cy, R * 0.295, 0, Math.PI * 2)
                ctx.fillStyle = "#001830"
                ctx.fill()

                // ── Primary specular (top-left) ──
                ctx.beginPath()
                ctx.arc(cx - R * 0.24, cy - R * 0.27, R * 0.158, 0, Math.PI * 2)
                ctx.fillStyle = "rgba(255,255,255,0.94)"
                ctx.fill()

                // ── Secondary micro-specular ──
                ctx.beginPath()
                ctx.arc(cx + R * 0.20, cy - R * 0.13, R * 0.068, 0, Math.PI * 2)
                ctx.fillStyle = "rgba(255,255,255,0.56)"
                ctx.fill()
            }
        }

        // ======================================================================
        //  2. HAPPY  — upward-arc squint with rosy cheek blush
        // ======================================================================
        Canvas {
            id:      happyCanvas
            anchors.fill: parent

            readonly property bool visActive:
                eyeUnit.currentExpression === "happy"
            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 220 } }
            onOpacityChanged: if (opacity > 0.5) requestPaint()

            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                var cx  = width  / 2
                var cy  = height / 2
                var R   = Math.min(width, height) * 0.38

                // Upward arc stroke
                ctx.beginPath()
                ctx.moveTo(cx - R * 1.08, cy + R * 0.22)
                ctx.quadraticCurveTo(cx, cy - R * 1.18, cx + R * 1.08, cy + R * 0.22)
                ctx.strokeStyle = eyeUnit.primaryColorStr
                ctx.lineWidth   = R * 0.50
                ctx.lineCap     = "round"
                ctx.stroke()

                // Rosy cheek ellipse (save/scale/arc trick — no ctx.ellipse needed)
                ctx.save()
                ctx.translate(cx, cy + R * 0.90)
                ctx.scale(1.0, 0.52)
                ctx.beginPath()
                ctx.arc(0, 0, R * 0.36, 0, Math.PI * 2)
                ctx.restore()
                ctx.fillStyle = "rgba(255,105,155,0.46)"
                ctx.fill()
            }
        }

        // ======================================================================
        //  3. LOVE  — heart-shaped pupil with sparkle glyph
        // ======================================================================
        Canvas {
            id:      loveCanvas
            anchors.fill: parent

            readonly property bool visActive:
                eyeUnit.currentExpression === "love"
            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 220 } }
            onOpacityChanged: if (opacity > 0.5) requestPaint()

            onPaint: {
                var ctx  = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                var cx = width  / 2
                var cy = height / 2
                var s  = Math.min(width, height) * 0.40

                // Heart via cubic béziers on a scaled axis
                ctx.save()
                ctx.translate(cx, cy - s * 0.04)
                ctx.scale(s * 0.122, s * 0.122)

                ctx.beginPath()
                ctx.moveTo(0,    1)
                ctx.bezierCurveTo(-0.55, -1.65, -4.55, -1.65, -4.55,  1.15)
                ctx.bezierCurveTo(-4.55,  3.60,  0,     6.20,  0,     7.85)
                ctx.bezierCurveTo( 0,     6.20,  4.55,  3.60,  4.55,  1.15)
                ctx.bezierCurveTo( 4.55, -1.65,  0.55, -1.65,  0,     1)

                var hg = ctx.createLinearGradient(0, -1.5, 0, 7.8)
                hg.addColorStop(0.0, "#ff85bb")
                hg.addColorStop(1.0, "#ff0e5a")
                ctx.fillStyle = hg
                ctx.fill()
                ctx.restore()

                // ✦ sparkle glyph
                ctx.fillStyle    = "rgba(255,255,255,0.96)"
                ctx.font         = "bold " + Math.round(height * 0.20) + "px sans-serif"
                ctx.textAlign    = "center"
                ctx.textBaseline = "middle"
                ctx.fillText("✦", cx + s * 0.64, cy - s * 0.66)
            }
        }

        // ======================================================================
        //  4. DIZZY  — continuously rotating triple-helix spiral + ⊛ glyph
        // ======================================================================
        Item {
            id:      dizzyLayer
            anchors.fill: parent

            readonly property bool visActive:
                eyeUnit.currentExpression === "dizzy"
            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 200 } }

            Canvas {
                id:      dizzyCanvas
                anchors.fill: parent

                // Continuously incremented rotation angle drives requestPaint
                property real spinAngle: 0

                NumberAnimation on spinAngle {
                    running:  dizzyLayer.visActive
                    from:     0;   to:   360
                    duration: 860
                    loops:    Animation.Infinite
                }
                onSpinAngleChanged: {
                    if (dizzyLayer.opacity > 0.04) requestPaint()
                }

                onPaint: {
                    var ctx   = getContext("2d")
                    ctx.clearRect(0, 0, width, height)

                    var cx    = width  / 2
                    var cy    = height / 2
                    var maxR  = Math.min(width, height) * 0.392
                    var turns = 3.0
                    var steps = 180

                    ctx.save()
                    ctx.translate(cx, cy)
                    ctx.rotate(spinAngle * Math.PI / 180)

                    // Segment-by-segment spiral: cyan (#00,#e5,#ff) → white
                    var prevX = 0, prevY = 0
                    for (var i = 0; i <= steps; i++) {
                        var p  = i / steps
                        var a  = p * Math.PI * 2 * turns
                        var r  = maxR * p
                        var px = Math.cos(a) * r
                        var py = Math.sin(a) * r
                        if (i > 0) {
                            ctx.beginPath()
                            ctx.moveTo(prevX, prevY)
                            ctx.lineTo(px, py)
                            var ri = Math.round(0   + p * 200)
                            var gi = Math.round(229 + p *  26)
                            ctx.strokeStyle = "rgb(" + ri + "," + gi + ",255)"
                            ctx.lineWidth   = maxR * 0.132
                            ctx.lineCap     = "round"
                            ctx.stroke()
                        }
                        prevX = px; prevY = py
                    }
                    ctx.restore()

                    // ⊛ centre glyph — static, white, drawn after restore
                    ctx.fillStyle    = "rgba(255,255,255,0.97)"
                    ctx.font         = "bold " + Math.round(Math.min(width, height) * 0.365)
                                       + "px sans-serif"
                    ctx.textAlign    = "center"
                    ctx.textBaseline = "middle"
                    ctx.fillText("⊛", cx, cy + 2)
                }
            }
        }

        // ======================================================================
        //  5. HUNGRY  — orange iris with heavy drooping eyelid mask
        // ======================================================================
        Canvas {
            id:      hungryCanvas
            anchors.fill: parent

            readonly property bool visActive:
                eyeUnit.currentExpression === "hungry"
            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 290 } }
            onOpacityChanged: if (opacity > 0.5) requestPaint()

            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                var cx = width  / 2
                var cy = height / 2
                var R  = Math.min(width, height) * 0.370

                // Orange iris
                var og = ctx.createRadialGradient(cx, cy, R * 0.10, cx, cy, R)
                og.addColorStop(0.0, "#ffaa66")
                og.addColorStop(1.0, "#c84400")
                ctx.beginPath()
                ctx.arc(cx, cy - R * 0.06, R, 0, Math.PI * 2)
                ctx.fillStyle = og
                ctx.fill()

                // Drooping black eyelid (lower half quadratic mask)
                ctx.beginPath()
                ctx.moveTo(-4, cy + R * 0.24)
                ctx.quadraticCurveTo(cx, cy + R * 1.08, width + 4, cy + R * 0.24)
                ctx.lineTo(width + 4, height + 4)
                ctx.lineTo(-4,        height + 4)
                ctx.closePath()
                ctx.fillStyle = "#040e18"
                ctx.fill()

                // Slit pupil
                ctx.beginPath()
                ctx.arc(cx, cy - R * 0.14, R * 0.268, 0, Math.PI * 2)
                ctx.fillStyle = "#150800"
                ctx.fill()

                // Specular
                ctx.beginPath()
                ctx.arc(cx - R * 0.22, cy - R * 0.30, R * 0.12, 0, Math.PI * 2)
                ctx.fillStyle = "rgba(255,255,255,0.78)"
                ctx.fill()
            }
        }

        // ======================================================================
        //  6. SLEEPING  — flat closed line with lash hints
        // ======================================================================
        Canvas {
            id:      sleepCanvas
            anchors.fill: parent

            readonly property bool visActive:
                eyeUnit.currentExpression === "sleeping"
            opacity: visActive ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 560 } }
            onOpacityChanged: if (opacity > 0.5) requestPaint()

            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                var cx = width  / 2
                var cy = height / 2
                var lW = width  * 0.70

                // Main closed-eye line with slight upward bow
                ctx.beginPath()
                ctx.moveTo(cx - lW / 2, cy + 1)
                ctx.quadraticCurveTo(cx, cy - 6, cx + lW / 2, cy + 1)
                ctx.strokeStyle = "#3a6a7a"
                ctx.lineWidth   = 5.5
                ctx.lineCap     = "round"
                ctx.stroke()

                // Faint upper eyelid arc
                ctx.beginPath()
                ctx.moveTo(cx - lW * 0.44, cy - 2)
                ctx.quadraticCurveTo(cx, cy - 10, cx + lW * 0.44, cy - 2)
                ctx.strokeStyle = "rgba(58,106,122,0.35)"
                ctx.lineWidth   = 2
                ctx.stroke()

                // Lash marks — direction flips per eye for realism
                var positions = [0.22, 0.40, 0.60, 0.80]
                var dir       = eyeUnit.isLeftEye ? -1 : 1
                for (var li = 0; li < positions.length; li++) {
                    var lx = cx - lW / 2 + lW * positions[li]
                    var ly = cy - 1
                    ctx.beginPath()
                    ctx.moveTo(lx, ly)
                    ctx.lineTo(lx + dir * 2.5, ly - 7.5)
                    ctx.strokeStyle = "#3a6a7a"
                    ctx.lineWidth   = 1.8
                    ctx.lineCap     = "round"
                    ctx.stroke()
                }
            }
        }

    } // end eyeShell

    // =========================================================================
    //  CANVAS COLOUR UTILITY FUNCTIONS
    //  These run in JavaScript scope and are called from Canvas.onPaint.
    //  They work with plain CSS hex strings (#rrggbb) to avoid QML-colour
    //  format ambiguity inside the Canvas 2D context.
    // =========================================================================
    function hexToRgba(hex, alpha) {
        var r = parseInt(hex.slice(1, 3), 16)
        var g = parseInt(hex.slice(3, 5), 16)
        var b = parseInt(hex.slice(5, 7), 16)
        return "rgba(" + r + "," + g + "," + b + "," + alpha.toFixed(3) + ")"
    }

    function lightenHex(hex, factor) {
        var r = Math.min(255, Math.round(parseInt(hex.slice(1, 3), 16) * factor))
        var g = Math.min(255, Math.round(parseInt(hex.slice(3, 5), 16) * factor))
        var b = Math.min(255, Math.round(parseInt(hex.slice(5, 7), 16) * factor))
        return "rgb(" + r + "," + g + "," + b + ")"
    }

    function darkenHex(hex, factor) {
        return lightenHex(hex, factor)   // reuses the same clamp logic
    }

    // Smooth blink — Behavior overridden by main.qml's explicit blinkSeq
    Behavior on eyeOpenness {
        NumberAnimation { duration: 85; easing.type: Easing.InOutQuad }
    }
}