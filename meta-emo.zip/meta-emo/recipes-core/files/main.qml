// ============================================================================
//  main.qml  —  EMO Robot Kiosk  —  Root Window & State Orchestrator
//
//  Target : AsteroidOS on Oppo Watch 41mm (sturgeon / wb205)
//  Qt     : 5.12 or later  (no Qt 5.14+ features used)
//  QPA    : hwcomposer (libhybris) or xcb/wayland for desktop development
//
//  State machine
//  ─────────────
//  "idle"      Default: breathing bob, randomised blink every 3–6 s
//  "happy"     Double-tap: lasts 3.2 s, then returns to idle
//  "love"      Single tap: lasts 2.4 s, then returns to idle
//  "dizzy"     Shake Δ > 9 m/s²: locked for 5 s
//  "hungry"    Battery ≤ 15 %: persists until charge rises above 15 %
//  "charging"  Charger connected: overrides hungry, persists while charging
//  "sleeping"  22:00–07:00 local or long-press toggle
//
//  Sensor / module dependencies
//  ─────────────────────────────
//  import QtSensors 5.11     → Accelerometer
//  import Nemo.Mce 1.0       → MceBatteryLevel, MceBatteryState
// ============================================================================

import QtQuick   2.12
import QtQuick.Window 2.2
import QtSensors 5.11
import Nemo.Mce  1.0

Window {
    id: root

    // ── Display ───────────────────────────────────────────────────────────────
    width:   Screen.width
    height:  Screen.height
    visible: true
    color:   "#000000"       // Pure black — maximises AMOLED contrast and power
    title:   "EMO Kiosk"
    flags:   Qt.Window | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint

    // ── Design geometry (scales with physical screen size) ────────────────────
    readonly property int eyeW:   Math.round(Screen.width  * 0.285)  // ≈91 px @ 320
    readonly property int eyeH:   Math.round(Screen.height * 0.215)  // ≈77 px @ 360
    readonly property int eyeRad: Math.round(eyeW * 0.20)
    readonly property int eyeGap: Math.round(Screen.width  * 0.075)

    // ── State machine ─────────────────────────────────────────────────────────
    property string currentState: "idle"
    property bool   isDizzy:      false
    property bool   isSleeping:   false
    property bool   isCharging:   false
    property bool   isHungry:     false

    // ── Organic animation scalars ──────────────────────────────────────────────
    property real breathScale: 1.0
    property real bobY:        0.0

    // ── Tap-gesture state ─────────────────────────────────────────────────────
    property int  tapCount:  0
    property real lastTapMs: 0

    // =========================================================================
    //  BREATHING + VERTICAL BOB (idle only)
    // =========================================================================
    SequentialAnimation {
        id:      breathAnim
        running: !root.isSleeping
        loops:   Animation.Infinite
        NumberAnimation {
            target: root; property: "breathScale"
            to: 1.028; duration: 1900; easing.type: Easing.InOutSine
        }
        NumberAnimation {
            target: root; property: "breathScale"
            to: 0.972; duration: 1900; easing.type: Easing.InOutSine
        }
    }

    SequentialAnimation {
        id:      bobAnim
        running: !root.isSleeping
        loops:   Animation.Infinite
        NumberAnimation {
            target: root; property: "bobY"
            to: -7; duration: 2300; easing.type: Easing.InOutSine
        }
        NumberAnimation {
            target: root; property: "bobY"
            to:  7; duration: 2300; easing.type: Easing.InOutSine
        }
    }

    // =========================================================================
    //  RANDOMISED BLINK SCHEDULER  (3 – 6 second interval, idle state only)
    // =========================================================================
    Timer {
        id:               blinkScheduler
        interval:         3000 + Math.random() * 3000
        repeat:           false
        running:          !root.isSleeping
        triggeredOnStart: false
        onTriggered: {
            if (root.currentState === "idle") {
                blinkSeq.start()
            }
            // Re-randomise interval before restarting
            interval = 3000 + Math.random() * 3000
            restart()
        }
    }

    // Simultaneous squish on both eyes — Qt 5.12-compatible (no 'targets:[…]')
    SequentialAnimation {
        id: blinkSeq
        ParallelAnimation {
            NumberAnimation {
                target: leftEye; property: "eyeOpenness"
                to: 0.0; duration: 72; easing.type: Easing.InQuad
            }
            NumberAnimation {
                target: rightEye; property: "eyeOpenness"
                to: 0.0; duration: 72; easing.type: Easing.InQuad
            }
        }
        PauseAnimation { duration: 58 }
        ParallelAnimation {
            NumberAnimation {
                target: leftEye; property: "eyeOpenness"
                to: 1.0; duration: 135; easing.type: Easing.OutBack
            }
            NumberAnimation {
                target: rightEye; property: "eyeOpenness"
                to: 1.0; duration: 135; easing.type: Easing.OutBack
            }
        }
    }

    // =========================================================================
    //  TIMED STATE RESETS
    // =========================================================================
    Timer {
        id: dizzyTimer
        interval: 5000
        onTriggered: {
            root.isDizzy      = false
            root.currentState = root.isCharging ? "charging"
                              : root.isHungry   ? "hungry"
                              : "idle"
        }
    }

    Timer {
        id: loveTimer
        interval: 2400
        onTriggered: {
            if (!root.isSleeping && !root.isDizzy)
                root.currentState = root.isHungry ? "hungry" : "idle"
        }
    }

    Timer {
        id: happyTimer
        interval: 3200
        onTriggered: {
            if (!root.isSleeping && !root.isDizzy)
                root.currentState = root.isHungry ? "hungry" : "idle"
        }
    }

    // =========================================================================
    //  SLEEP-TIME GATE  (22:00–07:00 local, polled every 60 s)
    // =========================================================================
    Timer {
        id:               sleepGate
        interval:         60000
        repeat:           true
        running:          true
        triggeredOnStart: true
        onTriggered: {
            var h           = new Date().getHours()
            var shouldSleep = (h >= 22 || h < 7)
            if      (shouldSleep  && !root.isSleeping) root.enterSleep()
            else if (!shouldSleep &&  root.isSleeping) root.exitSleep()
        }
    }

    function enterSleep() {
        root.isSleeping   = true
        root.currentState = "sleeping"
        breathAnim.stop()
        bobAnim.stop()
        blinkScheduler.stop()
        // Snap organic parameters to neutral so the sleeping expression
        // doesn't jitter when the animations are stopped mid-cycle
        root.bobY        = 0
        root.breathScale = 1.0
    }

    function exitSleep() {
        root.isSleeping   = false
        root.currentState = root.isHungry ? "hungry" : "idle"
        breathAnim.start()
        bobAnim.start()
        blinkScheduler.start()
    }

    // =========================================================================
    //  BATTERY MONITORING  (Nemo.Mce)
    //  MceBatteryLevel.percent : int  0–100
    //  MceBatteryState.value   : string  "charging" | "discharging" |
    //                                    "full" | "low" | "unknown"
    // =========================================================================
    MceBatteryLevel {
        id: mceLevel
        onPercentChanged: {
            root.isHungry = (percent <= 15)
            if (root.isHungry
                    && !root.isSleeping
                    && !root.isDizzy
                    && root.currentState !== "charging") {
                root.currentState = "hungry"
            } else if (!root.isHungry && root.currentState === "hungry") {
                root.currentState = "idle"
            }
        }
    }

    MceBatteryState {
        id: mceState
        onValueChanged: {
            root.isCharging = (value === "charging" || value === "full")
            if (root.isCharging && !root.isSleeping && !root.isDizzy) {
                root.currentState = "charging"
            } else if (!root.isCharging && root.currentState === "charging") {
                root.currentState = root.isHungry ? "hungry" : "idle"
            }
        }
    }

    // =========================================================================
    //  SHAKE / DIZZY DETECTION  (Accelerometer @ 25 Hz)
    //  Threshold: magnitude delta > 9 m/s²  (well above normal wrist motion)
    // =========================================================================
    property real _prevMag: 9.81

    Accelerometer {
        id:       accel
        active:   !root.isSleeping
        dataRate: 25

        onReadingChanged: {
            var x   = reading.x
            var y   = reading.y
            var z   = reading.z
            var mag = Math.sqrt(x * x + y * y + z * z)
            var dv  = Math.abs(mag - root._prevMag)
            root._prevMag = mag

            if (dv > 9.0 && !root.isDizzy && !root.isSleeping) {
                root.isDizzy      = true
                root.currentState = "dizzy"
                dizzyTimer.restart()
            }
        }
    }

    // =========================================================================
    //  EYE COLOUR HELPER  (called once per state change, not per-frame)
    // =========================================================================
    function eyeColorForState(state) {
        switch (state) {
            case "love":     return "#ff2d78"
            case "happy":    return "#00e5ff"
            case "dizzy":    return "#c8f0ff"
            case "hungry":   return "#ff6b35"
            case "charging": return "#00ff99"
            case "sleeping": return "#2a4a5a"
            default:         return "#00e5ff"   // canonical Living.AI EMO cyan
        }
    }

    // =========================================================================
    //  FACE CONTAINER
    //  All visual elements; breath/bob transforms applied as a group.
    // =========================================================================
    Item {
        id: faceContainer
        anchors.fill: parent

        // ── Subtle robot-head silhouette ──────────────────────────────────────
        Rectangle {
            id:      robotHead
            width:   Math.round(Screen.width  * 0.80)
            height:  Math.round(Screen.height * 0.66)
            radius:  Math.round(width * 0.13)
            color:   "#0a1520"
            border.color: "#00e5ff"
            border.width: 1
            opacity: 0.50
            anchors.centerIn: parent
            // Bob offset applied via y binding; Scale applied via transform
            y: (parent.height - height) / 2 + root.bobY

            transform: Scale {
                origin.x: robotHead.width  / 2
                origin.y: robotHead.height / 2
                xScale:   root.breathScale
                yScale:   root.breathScale
            }
        }

        // ── Eye pair ──────────────────────────────────────────────────────────
        Row {
            id:      eyesRow
            spacing: root.eyeGap
            // Centre vertically with a slight upward offset (robot eye placement)
            x: (parent.width  - width)  / 2
            y: (parent.height - height) / 2 - Screen.height * 0.028 + root.bobY

            transform: Scale {
                origin.x: eyesRow.width  / 2
                origin.y: eyesRow.height / 2
                xScale:   root.breathScale
                yScale:   root.breathScale
            }

            EyeUnit {
                id:                leftEye
                eyeW:              root.eyeW
                eyeH:              root.eyeH
                eyeRad:            root.eyeRad
                currentExpression: root.currentState
                primaryColorStr:   root.eyeColorForState(root.currentState)
                isLeftEye:         true
            }

            EyeUnit {
                id:                rightEye
                eyeW:              root.eyeW
                eyeH:              root.eyeH
                eyeRad:            root.eyeRad
                currentExpression: root.currentState
                primaryColorStr:   root.eyeColorForState(root.currentState)
                isLeftEye:         false
            }
        }

        // ── Charging badge ────────────────────────────────────────────────────
        Text {
            id: chargingBadge
            anchors {
                horizontalCenter: parent.horizontalCenter
                bottom:           parent.bottom
                bottomMargin:     Screen.height * 0.095
            }
            text:           "⚡"
            font.pixelSize: Math.round(Screen.height * 0.074)
            color:          "#ffe53b"
            opacity:        root.currentState === "charging" ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 360 } }

            SequentialAnimation on opacity {
                running: root.currentState === "charging"
                loops:   Animation.Infinite
                NumberAnimation { to: 1.0;  duration: 430 }
                NumberAnimation { to: 0.22; duration: 430 }
            }
        }

        // ── Hunger label ──────────────────────────────────────────────────────
        Text {
            id: hungerLabel
            anchors {
                horizontalCenter: parent.horizontalCenter
                bottom:           parent.bottom
                bottomMargin:     Screen.height * 0.095
            }
            text:               "NOM♦NOM"
            font.pixelSize:     Math.round(Screen.height * 0.046)
            font.letterSpacing: 3
            font.bold:          true
            color:              "#ff8c00"
            opacity:            root.currentState === "hungry" ? 1.0 : 0.0
            Behavior on opacity { NumberAnimation { duration: 300 } }

            SequentialAnimation on scale {
                running: root.currentState === "hungry"
                loops:   Animation.Infinite
                NumberAnimation { to: 1.12; duration: 700; easing.type: Easing.InOutSine }
                NumberAnimation { to: 0.88; duration: 700; easing.type: Easing.InOutSine }
            }
        }

        // ── Love pulse ring ───────────────────────────────────────────────────
        Rectangle {
            id:           lovePulseRing
            width:        Screen.width * 0.88
            height:       width
            radius:       width / 2
            color:        "transparent"
            border.color: "#ff2d78"
            border.width: 3
            anchors.centerIn: parent
            opacity:      0
            scale:        0.5

            SequentialAnimation {
                id:      lovePulseAnim
                running: root.currentState === "love"
                loops:   4
                ParallelAnimation {
                    NumberAnimation {
                        target: lovePulseRing; property: "scale"
                        from: 0.42; to: 1.18; duration: 580
                        easing.type: Easing.OutQuad
                    }
                    NumberAnimation {
                        target: lovePulseRing; property: "opacity"
                        from: 0.88; to: 0.0;  duration: 580
                    }
                }
                PauseAnimation { duration: 75 }
            }
        }

        // ── ZZZ sleep particles (four staggered instances) ────────────────────
        Repeater {
            model: 4
            delegate: ZzzParticle {
                particleIndex: index
                active:        root.isSleeping
                // Anchor above the eye row centre, slightly randomised per index
                baseX: eyesRow.x + eyesRow.width  * 0.44 + index * 10
                baseY: eyesRow.y - 16
            }
        }
    }

    // =========================================================================
    //  TOUCH / GESTURE HANDLER
    //  Single tap   → "love"  (2.4 s, resets to idle)
    //  Double tap   → "happy" (3.2 s, resets to idle)
    //  Long press   → toggle sleep ↔ wake
    // =========================================================================
    MouseArea {
        id:          touchArea
        anchors.fill: parent

        onClicked: {
            var now = Date.now()
            root.tapCount = (now - root.lastTapMs < 380)
                            ? root.tapCount + 1
                            : 1
            root.lastTapMs = now
            tapResolveTimer.restart()
        }

        onPressAndHold: {
            // Cancel any pending tap resolution so long-press wins
            root.tapCount = 0
            tapResolveTimer.stop()
            if (root.isSleeping) root.exitSleep()
            else                 root.enterSleep()
        }
    }

    // Resolve single vs double tap after the double-tap window closes
    Timer {
        id:       tapResolveTimer
        interval: 370
        onTriggered: {
            if (root.isSleeping || root.isDizzy) {
                root.tapCount = 0
                return
            }
            if (root.tapCount === 1) {
                root.currentState = "love"
                loveTimer.restart()
            } else if (root.tapCount >= 2) {
                root.currentState = "happy"
                happyTimer.restart()
            }
            root.tapCount = 0
        }
    }

    // =========================================================================
    //  STARTUP
    // =========================================================================
    Component.onCompleted: {
        var h = new Date().getHours()
        if (h >= 22 || h < 7) root.enterSleep()
    }
}