// ============================================================================
//  main.cpp  —  EMO Kiosk Runner
//  Minimal Qt5 QML application host for AsteroidOS / libhybris hardware.
//
//  Key design choices:
//  • QGuiApplication (not QApplication) — no QtWidgets overhead
//  • QQmlApplicationEngine for full Qt Quick component support including
//    inline Component{}, Loader{}, and multi-file QML imports
//  • Platform plugin (hwcomposer) and input plugins (evdevtouch) are passed
//    as command-line arguments by the systemd service — this binary does not
//    hard-code device paths
//  • fullScreen() is called on the root Window if it does not already
//    have Qt::WindowFullScreen set via the QML flags property
//
//  Build: see CMakeLists.txt in this directory.
//  Install: /usr/bin/emo-kiosk-runner   (handled by emo-kiosk-runner.bb)
//
//  Runtime invocation (from systemd service):
//    /usr/bin/emo-kiosk-runner \
//        -plugin evdevtouch:/dev/input/event1 \
//        /usr/share/emo-kiosk/main.qml
// ============================================================================

#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQuickWindow>
#include <QUrl>
#include <QFile>
#include <QFileInfo>
#include <QDebug>
#include <QCommandLineParser>
#include <QScreen>
#include <QtGlobal>

// ---------------------------------------------------------------------------
static const char *EMO_DEFAULT_QML = "/usr/share/emo-kiosk/main.qml";
static const char *EMO_VERSION     = "1.0.0";

// ---------------------------------------------------------------------------
int main(int argc, char *argv[]) {
    // ── Pre-application settings (must precede QGuiApplication ctor) ─────────
    // Disable mouse cursor — kiosk mode, touch-only device
    qputenv("QT_QPA_NO_CURSOR", "1");

    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling, true);
    QCoreApplication::setAttribute(Qt::AA_UseHighDpiPixmaps,    true);

    QCoreApplication::setApplicationName("emo-kiosk");
    QCoreApplication::setApplicationVersion(EMO_VERSION);
    QCoreApplication::setOrganizationName("meta-emo");

    // QGuiApplication parses and strips -platform / -plugin arguments
    // internally before any userland code sees argv.
    QGuiApplication app(argc, argv);

    // ── Command-line: optional QML path override ──────────────────────────────
    QCommandLineParser parser;
    parser.setApplicationDescription(
        "EMO Robot Kiosk — lightweight QML runtime for AsteroidOS");
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument(
        "qml",
        QStringLiteral("QML entry point to load (default: ") +
        QString::fromLatin1(EMO_DEFAULT_QML) + ")",
        QStringLiteral("[qml-path]"));
    parser.process(app);

    const QStringList positional = parser.positionalArguments();
    const QString qmlPath = positional.isEmpty()
                          ? QString::fromLatin1(EMO_DEFAULT_QML)
                          : positional.first();

    // ── Sanity-check QML file ─────────────────────────────────────────────────
    if (!QFile::exists(qmlPath)) {
        qCritical().nospace()
            << "[EMO Kiosk v" << EMO_VERSION
            << "] FATAL: QML file not found: " << qmlPath
            << "\n  Hint: install emo-core-kiosk, or pass a custom