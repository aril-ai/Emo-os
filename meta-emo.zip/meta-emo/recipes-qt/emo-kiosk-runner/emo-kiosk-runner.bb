# ============================================================================
# emo-kiosk-runner.bb
#
# Builds the minimal C++ Qt5 QML runtime host. This replaces qmlscene
# to give us precise control over platform plugin loading, import paths,
# and fullscreen enforcement with no unnecessary overhead.
# ============================================================================

SUMMARY     = "EMO Kiosk Runner — lightweight Qt5 QML application host"
DESCRIPTION = "Standalone C++ executable that loads and displays the EMO kiosk \
QML fullscreen via the hwcomposer QPA plugin on AsteroidOS/libhybris hardware."
LICENSE     = "MIT"
LIC_FILES_CHKSUM = \
    "file://${COMMON_LICENSE_DIR}/MIT;md5=0835ade698e0bcf8506ecda2f7b4f302"

SRC_URI = " \
    file://main.cpp;subdir=src \
    file://CMakeLists.txt;subdir=src   \
"

S = "${WORKDIR}/src"

inherit cmake 

DEPENDS = " \
    qtbase          \
    qtdeclarative   \
"

RDEPENDS:${PN} = " \
    qtbase-plugins          \
    qtdeclarative           \
    qtsensors               \
    nemo-qml-plugin-mce     \
    ${@bb.utils.contains('DISTRO_FEATURES', 'x11', '', \
       'qt5-plugin-platform-hwcomposer', d)} \
"

do_install:append() {
    if [ ! -f "${D}${bindir}/emo-kiosk-runner" ]; then
        bbfatal "emo-kiosk-runner binary missing after cmake install — check build log."
    fi
}

FILES:${PN} = "${bindir}/emo-kiosk-runner"
